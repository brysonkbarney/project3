#!/usr/bin/env bash
sudo certbot -n -d cougarconnect.is404.net --nginx --agree-tos --email brysonkbarney@gmail.com